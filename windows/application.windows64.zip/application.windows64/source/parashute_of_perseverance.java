import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import controlP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class parashute_of_perseverance extends PApplet {



ControlP5 cp5;

String word1 = "";
String word2 = "";
String word3 = "";
String word4 = "";

ring[] fragment1 = new ring[100]; 
ring[] fragment2 = new ring[100]; 
ring[] fragment3 = new ring[100]; 
ring[] fragment4 = new ring[100];

public int[] memory1 = new int[100];
public int[] memory2 = new int[100];
public int[] memory3 = new int[100];
public int[] memory4 = new int[100];

int len_field = 300;


public void setup(){
  
  
  surface.setResizable(true);
  surface.setTitle("Parashute of Perseverance");
  background(100,100,100);
  
  for (int i = 0; i < fragment1.length; i++ ) {
   fragment1[i]= new ring();  
   fragment2[i]= new ring(); 
   fragment3[i]= new ring(); 
   fragment4[i]= new ring(); 
   
 }
 Buttons();            
                   

}

public void draw(){
  float ring_len = min(width,height)/10;
  
  float x_pos = ring_len*5;
  float y_pos = height/2;
  
  int num1=0;
  int num2=0;
  int num3=0;
  int num4=0;
  
  submit();
  
  for (float a = 0; a<TWO_PI; a += TWO_PI/100){
    float x2 = x_pos + cos(a)*ring_len;
    float y2 = y_pos + sin(a)*ring_len;
    
    float x3 = x_pos + cos(a+TWO_PI/100)*ring_len;
    float y3 = y_pos + sin(a+TWO_PI/100)*ring_len;
    
    float x1 = x_pos + cos(a)*ring_len/2;
    float y1 = y_pos + sin(a)*ring_len/2;
    
    float x4 = x_pos + cos(a+TWO_PI/100)*ring_len/2;
    float y4 = y_pos + sin(a+TWO_PI/100)*ring_len/2; 

    fragment1[num1].sector(x1,y1,x2,y2,x3,y3,x4,y4,memory1[num1]); num1++;}  
    
     
    for (float a = 0; a<TWO_PI; a += TWO_PI/100){
    float x2 = x_pos + cos(a)*ring_len*2;
    float y2 = y_pos + sin(a)*ring_len*2;
    
    float x3 = x_pos + cos(a+TWO_PI/100)*ring_len*2;
    float y3 = y_pos + sin(a+TWO_PI/100)*ring_len*2;
    
    float x1 = x_pos + cos(a)*ring_len;
    float y1 = y_pos + sin(a)*ring_len;
    
    float x4 = x_pos + cos(a+TWO_PI/100)*ring_len;
    float y4 = y_pos + sin(a+TWO_PI/100)*ring_len;
    
    fragment2[num2].sector(x1,y1,x2,y2,x3,y3,x4,y4,memory2[num2]); num2++;} 
    
    
    for (float a = 0; a<TWO_PI; a += TWO_PI/100){
    float x2 = x_pos + cos(a)*ring_len*4;
    float y2 = y_pos + sin(a)*ring_len*4;
    
    float x3 = x_pos + cos(a+TWO_PI/100)*ring_len*4;
    float y3 = y_pos + sin(a+TWO_PI/100)*ring_len*4;
    
    float x1 = x_pos + cos(a)*ring_len*2;
    float y1 = y_pos + sin(a)*ring_len*2;
    
    float x4 = x_pos + cos(a+TWO_PI/100)*ring_len*2;
    float y4 = y_pos + sin(a+TWO_PI/100)*ring_len*2;
    
    fragment3[num3].sector(x1,y1,x2,y2,x3,y3,x4,y4,memory3[num3]); num3++;} 
    
    
    for (float a = 0; a<TWO_PI; a += TWO_PI/100){
    float x2 = x_pos + cos(a)*ring_len*5;
    float y2 = y_pos + sin(a)*ring_len*5;
    
    float x3 = x_pos + cos(a+TWO_PI/100)*ring_len*5;
    float y3 = y_pos + sin(a+TWO_PI/100)*ring_len*5;
    
    float x1 = x_pos + cos(a)*ring_len*4.5f;
    float y1 = y_pos + sin(a)*ring_len*4.5f;
    
    float x4 = x_pos + cos(a+TWO_PI/100)*ring_len*4.5f;
    float y4 = y_pos + sin(a+TWO_PI/100)*ring_len*4.5f;
    
    fragment4[num4].sector(x1,y1,x2,y2,x3,y3,x4,y4,memory4[num4]); num4++;} 
           
}



public void submit(){
  word1 = (cp5.get(Textfield.class,"RING1").getText()).toUpperCase(); Word2Bin(word1,memory1);
  word2 = (cp5.get(Textfield.class,"RING2").getText()).toUpperCase(); Word2Bin(word2,memory2);
  word3 = (cp5.get(Textfield.class,"RING3").getText()).toUpperCase(); Word2Bin(word3,memory3);
  word4 = (cp5.get(Textfield.class,"RING4").getText()).toUpperCase(); Word2Bin(word4,memory4);
  
  
}


public void Word2Bin(String word, int[] memory){
  

  String abc = "_ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 *(),.";
  String bin_code = "";
  int place;
  if(word.length()>10){word="";}
  
  word = word.toUpperCase();
  
  for(int i = 0; i<word.length(); i++){
    
    place = abc.indexOf(word.charAt(i));
    bin_code = bin_code + (binary(place,10));}
    
  for(int i = 0; i<bin_code.length(); i++){
    memory[i] = (bin_code.charAt(i));}}
    
public void Buttons(){
  float x_place = width*0.6f;
    if ((width<=1280)||(height<=768)){x_place=800;len_field=200;}
    
   
  cp5 = new ControlP5(this);
  for(int i = 1; i<5; i++){
           cp5.addTextfield("RING"+i)
                   .setPosition(x_place, 100+100*i)
                   .setSize(len_field, 25)
                   .setFont(createFont("Times New Roman",25));}
}
  
public class ring{
  PVector[] vertices = new PVector[4];
 
  
  ring(){}
  
  
  boolean flag = false;
  
  
  public void sector(float x1, float y1, float x2, float y2, float x3, float y3, float x4, float y4, int memory){
     
     vertices[0] = new PVector(x1,y1);
     vertices[1] = new PVector(x2,y2);
     vertices[2] = new PVector(x3,y3);
     vertices[3] = new PVector(x4,y4);
     
     boolean hit = polyPoint(x1,y1,x2,y2,x3,y3,x4,y4);
     
    if(hit && mousePressed) {flag = !flag;}
    
    
    
    if (flag) {fill(216,113,52);}
    else{fill(245,242,242);}
    
    if(PApplet.parseInt(memory) == 49){flag=true;}
    if(PApplet.parseInt(memory) == 48){flag=false;}
  
     
     beginShape();
    for (PVector v : vertices) {
    vertex(v.x, v.y);}
     endShape(CLOSE);
  
  }

   public boolean polyPoint(float x1, float y1, float x2, float y2, float x3, float y3, float x4, float y4) {
     boolean collision = false;
  
     PVector[] points = new PVector[4];
     
     points[0] = new PVector(x1,y1);
     points[1] = new PVector(x2,y2);
     points[2] = new PVector(x3,y3);
     points[3] = new PVector(x4,y4);

  // go through each of the vertices, plus
  // the next vertex in the list
  int next = 0;
  for (int current=0; current<4; current++) {

    // get next vertex in list
    // if we've hit the end, wrap around to 0
    next = current+1;
    if (next == 4) next = 0;

    // get the PVectors at our current position
    // this makes our if statement a little cleaner
    PVector vc = points[current];    // c for "current"
    PVector vn = points[next];       // n for "next"
    

    // compare position, flip 'collision' variable
    // back and forth
    if (((vc.y >= mouseY && vn.y < mouseY) || (vc.y < mouseY && vn.y >= mouseY)) &&
         (mouseX < (vn.x-vc.x)*(mouseY-vc.y) / (vn.y-vc.y)+vc.x)) {
            collision = !collision;
    }
  }
  return collision;
  
}

}
  public void settings() {  size(displayWidth,displayHeight); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "parashute_of_perseverance" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
